# 🎓 Student Management System

A full-stack **Student Management System** built with **Java, Spring Boot, Spring Data JPA, MySQL, Thymeleaf, HTML, CSS and JavaScript**.

The application provides a clean dashboard for managing student records, including adding, viewing, searching, updating and deleting students. It also includes authentication/security, department information, dashboard statistics and a responsive web interface.

---

## 📌 Project Overview

The Student Management System is designed to simplify student record management through a centralized web application.

Instead of maintaining student information manually, an administrator can use the application to:

- View all registered students
- Add new students
- Update existing student information
- Delete student records
- Search students by name
- View student departments
- View dashboard statistics
- Access protected application pages
- Manage student information through REST APIs
- Store student data in a MySQL database

The project follows a layered Spring Boot architecture with separate controller, service, repository, entity, DTO, mapper, security and exception-handling components.

---

## ✨ Features

### 👨‍🎓 Student Management
- Add a new student
- View all students
- Update student details
- Delete student records
- Search students by name
- Display student information in a structured table
- Show department badges
- Display Edit and Delete actions

### 📊 Dashboard
- Total Students
- Total Departments
- Total Records
- Course information area
- Student list
- Quick Add Student button
- Search functionality
- Refresh option

### 🔐 Authentication & Security
The project includes Spring Security and JWT-related components for securing application access.

Security-related components include:
- Authentication controller
- Security configuration
- JWT utility
- JWT test controller
- Protected application access

### 🏫 Department Section
The dashboard includes:
- CSE — Computer Science
- CSE-AIML — Artificial Intelligence
- CSM — Computer Science & ML
- ECE — Electronics
- EEE — Electrical Engineering
- MECH — Mechanical Engineering

### 🔎 Search
Students can be searched by name from the dashboard search box.

### 📱 Responsive UI
The dashboard uses responsive CSS for different screen sizes and includes:
- Sidebar navigation
- Header and search bar
- Dashboard cards
- Student table
- Student form
- Department cards
- Reports section
- Settings section

---

# 🖥️ Application Screenshots

## 1. Dashboard & Student List

The main dashboard provides a quick overview of the system and displays registered students with their details and available actions.

![Student Management System Dashboard](./screenshots/dashboard.png)

**Dashboard includes:**
- Total student count
- Department count
- Course section
- Total database records
- Student list
- Search
- Refresh
- Export UI
- Filter UI
- Add Student
- Edit and Delete actions

---

## 2. Add New Student

The Add New Student section allows the administrator to enter student information.

![Add New Student](screenshots/add-student.png)

The form contains:
- Student Name
- Email
- Department
- Phone Number
- Add Student button
- Cancel button

The same form is also used for updating an existing student when edit mode is activated.

---

## 3. Departments, Reports & Settings

The lower sections of the dashboard provide department information along with dedicated areas for reports and application settings.

![Departments Reports and Settings](screenshots/departments-reports-settings.png)

The department section currently displays:
- CSE
- CSE-AIML
- CSM
- ECE
- EEE
- MECH

The Reports and Settings sections provide dedicated areas that can be extended with additional functionality in future versions.

---

# 🛠️ Technologies Used

## Backend
- **Java 21**
- **Spring Boot 3.5.3**
- **Spring Web**
- **Spring Data JPA**
- **Hibernate**
- **Spring Validation**
- **Spring Security**
- **JWT**
- **Maven**

## Frontend
- **HTML5**
- **CSS3**
- **JavaScript**
- **Thymeleaf**

## Database
- **MySQL**

## API & Development Tools
- **REST APIs**
- **Swagger / OpenAPI**
- **Postman**
- **IntelliJ IDEA**
- **Git**
- **GitHub**

---

# 🏗️ Project Architecture

The project follows a layered architecture:

```text
Client / Browser
       │
       ▼
   Controller
       │
       ▼
     Service
       │
       ▼
   Repository
       │
       ▼
      JPA
       │
       ▼
     MySQL
```

### Controller
Handles incoming HTTP requests.

Examples:
- `StudentController`
- `DashboardController`
- `AuthController`

### Service
Contains application/business logic.

Example:
- `StudentService`

### Repository
Handles database operations using Spring Data JPA.

Example:
- `StudentRepository`

### Entity
Represents student data stored in the database.

Example:
- `Student`

### DTO
Used for structured data transfer.

Examples:
- `StudentDTO`
- `LoginRequest`

### Mapper
Converts between entity and DTO representations.

Example:
- `StudentMapper`

### Exception Handling
Centralized exception handling includes:
- `GlobalExceptionHandler`
- `StudentNotFoundException`

### Security
Security-related classes include:
- `SecurityConfig`
- `JwtUtil`
- `AuthController`
- `JwtTestController`

---

# 📂 Project Structure

```text
student-management-system/
│
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/rck/studentmanagementsystem/
│   │   │       ├── controller/
│   │   │       │   ├── DashboardController.java
│   │   │       │   └── StudentController.java
│   │   │       ├── dto/
│   │   │       │   ├── LoginRequest.java
│   │   │       │   └── StudentDTO.java
│   │   │       ├── entity/
│   │   │       │   └── Student.java
│   │   │       ├── exception/
│   │   │       │   ├── GlobalExceptionHandler.java
│   │   │       │   └── StudentNotFoundException.java
│   │   │       ├── mapper/
│   │   │       │   └── StudentMapper.java
│   │   │       ├── repository/
│   │   │       │   └── StudentRepository.java
│   │   │       ├── response/
│   │   │       │   └── ApiResponse.java
│   │   │       ├── security/
│   │   │       │   ├── AuthController.java
│   │   │       │   ├── JwtTestController.java
│   │   │       │   ├── JwtUtil.java
│   │   │       │   └── SecurityConfig.java
│   │   │       └── service/
│   │   │           └── StudentService.java
│   │   └── resources/
│   │       ├── static/
│   │       │   ├── css/
│   │       │   │   ├── dashboard-style.css
│   │       │   │   └── style.css
│   │       │   └── js/
│   │       │       ├── dashboard-script.js
│   │       │       └── script.js
│   │       ├── templates/
│   │       │   ├── dashboard.html
│   │       │   └── index.html
│   │       └── application.properties
│   └── test/
│
├── pom.xml
├── README.md
└── screenshots/
```

---

# 🔄 Student CRUD Operations

| Operation | Purpose |
|---|---|
| **Create** | Add a new student |
| **Read** | View student records |
| **Update** | Modify student information |
| **Delete** | Remove student records |

The dashboard provides Edit and Delete actions directly in the student table.

---

# 🌐 REST API

The backend exposes REST endpoints for student management:

```text
GET    /api/students
GET    /api/students/{id}
POST   /api/students
PUT    /api/students/{id}
DELETE /api/students/{id}
GET    /api/students/search?name={name}
```

The exact request and response structure is defined by the controllers and DTOs in the project.

---

# 🗄️ Database

The application uses **MySQL** for persistent student data.

Development configuration is provided through:

```text
src/main/resources/application.properties
```

Example:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/student_management
spring.datasource.username=root
spring.datasource.password=YOUR_PASSWORD

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
```

> **Security note:** Never commit your real database password, JWT secret, production credentials or other sensitive information to GitHub.

For deployment, use environment variables or the hosting provider's secret/configuration settings.

---

# ▶️ How to Run Locally

## 1. Clone the repository

```bash
git clone <your-github-repository-url>
```

## 2. Open the project

Open it in IntelliJ IDEA or another Java IDE.

## 3. Configure MySQL

Create the database:

```sql
CREATE DATABASE student_management;
```

Configure the database username and password in `application.properties`.

## 4. Build the project

```bash
mvn clean install
```

On Windows, you can also use:

```bash
mvnw.cmd clean install
```

## 5. Run the application

Run:

```text
StudentManagementSystemApplication
```

or:

```bash
mvn spring-boot:run
```

## 6. Open the application

```text
http://localhost:8080/dashboard
```

---

# 🔐 Configuration & Environment Variables

For production deployment, sensitive values should be supplied through environment variables.

For example:

```properties
spring.datasource.url=${DB_URL}
spring.datasource.username=${DB_USERNAME}
spring.datasource.password=${DB_PASSWORD}

spring.security.user.name=${ADMIN_USERNAME}
spring.security.user.password=${ADMIN_PASSWORD}
```

This keeps credentials outside the source code.

---

# 🧪 Testing

The project can be tested using:
- Browser
- Postman
- Swagger UI
- Spring Boot tests

CRUD APIs can be tested independently before using them through the dashboard.

---

# 📖 Swagger / OpenAPI

The project includes SpringDoc OpenAPI support.

When running locally:

```text
http://localhost:8080/swagger-ui/index.html
```

Swagger UI can be used to inspect and test available REST APIs.

---

# 🎨 User Interface

The dashboard was designed as an administrative interface with:

- Dark sidebar navigation
- Modern header
- Search bar
- Admin profile area
- Colorful statistics cards
- Student management table
- Add Student form
- Department cards
- Reports section
- Settings section
- Responsive layout

---

# 🚀 Deployment

The application is prepared for deployment as a Spring Boot application.

Production deployment requires:
1. Java runtime
2. MySQL-compatible production database
3. Database environment variables
4. Application security credentials
5. Production server port
6. Build/deployment configuration

The application should not use a `localhost` database URL in production because `localhost` refers to the deployment server itself.

---

# 🔮 Future Enhancements

Possible improvements include:

- Role-based access control
- Student profile pages
- Advanced filtering
- Department-based filtering
- Course management
- Attendance management
- Student profile photos
- Excel/PDF export
- Detailed reports
- Dashboard charts
- Improved pagination
- Improved validation
- Email notifications
- Cloud database integration
- Production deployment

---

# 📚 Learning Outcomes

This project provided practical experience with:

- Java backend development
- Spring Boot
- REST API development
- Spring Data JPA
- Hibernate
- MySQL integration
- CRUD operations
- DTO pattern
- Entity-to-DTO mapping
- Exception handling
- Spring Security
- JWT concepts
- HTML/CSS/JavaScript integration
- Thymeleaf
- API testing
- Git and GitHub
- Maven

---

# 👨‍💻 Author

**Raavi Charan Kumar**

B.Tech Computer Science Engineering

### Areas of Interest
- Java Development
- Spring Boot
- Backend Development
- Full-Stack Development
- Data Structures & Algorithms
- Software Engineering

---

# ⭐ Project Highlights

The project demonstrates an end-to-end student management workflow:

```text
Browser
   ↓
HTML / CSS / JavaScript / Thymeleaf
   ↓
Spring Boot Controllers
   ↓
Service Layer
   ↓
Spring Data JPA / Hibernate
   ↓
MySQL
```

It combines backend development, database integration, REST APIs, security and a modern administrative dashboard into one application.

---

## 📌 Repository

The project is maintained using Git and GitHub for version control and source-code management.

If you find the project useful, consider giving the repository a ⭐.
