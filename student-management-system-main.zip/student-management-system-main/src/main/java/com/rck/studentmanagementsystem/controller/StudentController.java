package com.rck.studentmanagementsystem.controller;
import java.util.List;
import com.rck.studentmanagementsystem.service.StudentService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.rck.studentmanagementsystem.entity.Student;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.List;
import org.springframework.web.bind.annotation.PathVariable;
import java.util.Optional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PutMapping;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.http.ResponseEntity;
import com.rck.studentmanagementsystem.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;

@Tag(
        name = "Student Management APIs",
        description = "Operations related to Student Management System"
)
@RestController
@RequestMapping("/api")
public class StudentController {

    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }
    @Operation(
            summary = "Student Count",
            description = "Returns total number of students"
    )
    @GetMapping("/count")
    public long getStudentCount() {
        return studentService.getStudentCount();
    }
    @Operation(
            summary = "Save Student",
            description = "Adds a new student into database"
    )
    @PostMapping("/students")
    public ResponseEntity<ApiResponse> saveStudent(@Valid @RequestBody Student student) {

        ApiResponse response = new ApiResponse(
                "Student saved successfully",
                201,
                studentService.saveStudent(student)
        );

        return ResponseEntity.status(201).body(response);

    }
    @Operation(
            summary = "Get All Students",
            description = "Fetches all students from database"
    )
    @GetMapping("/students")
    public Page<Student> getAllStudents(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size) {

        return studentService.getAllStudents(page, size);
    }
    @GetMapping("/students/search")
    public List<Student> searchStudents(@RequestParam String name) {
        return studentService.searchStudentsByName(name);
    }

    @Operation(
            summary = "Sort Students",
            description = "Returns students sorted by specified field"
    )
    @GetMapping("/students/sort")
    public List<Student> getStudentsSorted(
            @RequestParam String field) {

        return studentService.getStudentsSorted(field);
    }
    @Operation(
            summary = "Get Student By ID",
            description = "Fetches a student using student ID"
    )
    @GetMapping("/students/{id}")
    public Student getStudentById(@PathVariable Long id) {
        return studentService.getStudentById(id);
    }
    @Operation(
            summary = "Delete Student",
            description = "Deletes a student by ID"
    )
    @DeleteMapping("/students/{id}")
    public String deleteStudent(@PathVariable Long id) {
        studentService.deleteStudent(id);
        return "Student deleted successfully";
    }
    @Operation(
            summary = "Update Student",
            description = "Updates student details by ID"
    )
    @PutMapping("/students/{id}")
    public Student updateStudent(@PathVariable Long id,
                                 @RequestBody Student student) {

        return studentService.updateStudent(id, student);
    }
}