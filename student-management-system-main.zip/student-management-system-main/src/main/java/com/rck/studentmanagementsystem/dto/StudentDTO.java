package com.rck.studentmanagementsystem.dto;
import lombok.Data;

@Data
public class StudentDTO {
    private Long id;
    private String name;
    private String email;
    private String department;
    private String phone;

}
