package com.rck.studentmanagementsystem.mapper;

import com.rck.studentmanagementsystem.dto.StudentDTO;
import com.rck.studentmanagementsystem.entity.Student;

public class StudentMapper {

    public static StudentDTO toDTO(Student student) {
        StudentDTO dto = new StudentDTO();

        dto.setId(student.getId());
        dto.setName(student.getName());
        dto.setEmail(student.getEmail());
        dto.setDepartment(student.getDepartment());
        dto.setPhone(student.getPhone());

        return dto;
    }

    public static Student toEntity(StudentDTO dto) {
        Student student = new Student();

        student.setId(dto.getId());
        student.setName(dto.getName());
        student.setEmail(dto.getEmail());
        student.setDepartment(dto.getDepartment());
        student.setPhone(dto.getPhone());

        return student;
    }
}