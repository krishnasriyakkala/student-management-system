package com.rck.studentmanagementsystem.security;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JwtTestController {

    private final JwtUtil jwtUtil;

    public JwtTestController(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @GetMapping("/token")
    public String generateToken() {
        return jwtUtil.generateToken("charan");
    }

    @GetMapping("/validate")
    public String validateToken() {

        String token = jwtUtil.generateToken("charan");

        boolean valid = jwtUtil.validateToken(token, "charan");

        return "Token Valid : " + valid;
    }
}