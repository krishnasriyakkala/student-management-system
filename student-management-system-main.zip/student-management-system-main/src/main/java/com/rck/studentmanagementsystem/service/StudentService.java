package com.rck.studentmanagementsystem.service;
import com.rck.studentmanagementsystem.entity.Student;
import com.rck.studentmanagementsystem.repository.StudentRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.rck.studentmanagementsystem.exception.StudentNotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Service
public class StudentService {
    private static final Logger logger =
            LoggerFactory.getLogger(StudentService.class);

    private final StudentRepository studentRepository;

    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }
    public long getStudentCount() {

        return studentRepository.count();
    }
    public Student saveStudent(Student student) {
        logger.info("Saving student: {}", student.getName());
        return studentRepository.save(student);
    }
    public Page<Student> getAllStudents(int page, int size) {
        logger.info("Fetching all students");
        return studentRepository.findAll(PageRequest.of(page, size));
    }
    public List<Student> getStudentsSorted(String field) {
        return studentRepository.findAll(Sort.by(field));
    }
    public List<Student> searchStudentByName(String name) {
        return studentRepository.findByNameContainingIgnoreCase(name);
    }
    public Student getStudentById(Long id) {
        logger.info("Fetching student with id {}", id);
        return studentRepository.findById(id)
                .orElseThrow(() ->
                        new StudentNotFoundException("Student not found with id: " + id));
    }
    public void deleteStudent(Long id) {
        logger.info("Deleting student with id {}", id);
        studentRepository.deleteById(id);
    }
    public Student updateStudent(Long id, Student student) {
        logger.info("Updating student with id {}", id);
        Student existingStudent = studentRepository.findById(id).orElse(null);

        if(existingStudent != null) {
            existingStudent.setName(student.getName());
            existingStudent.setEmail(student.getEmail());
            existingStudent.setDepartment(student.getDepartment());
            existingStudent.setPhone(student.getPhone());

            return studentRepository.save(existingStudent);
        }

        return null;
    }

    public List<Student> searchStudentsByName(String name) {
        return studentRepository.findByNameContainingIgnoreCase(name);
    }
}