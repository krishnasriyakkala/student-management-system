/* =========================================================
   STUDENT MANAGEMENT SYSTEM
   DASHBOARD JAVASCRIPT - NEW VERSION
   ========================================================= */


/* =========================================================
   GLOBAL VARIABLES
   ========================================================= */

let editId = null;

let allStudents = [];

let currentPage = 1;

const studentsPerPage = 10;


/* =========================================================
   PAGE LOAD
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    /*
     * Hide Add Student form initially
     */
    const form =
        document.getElementById("studentFormSection");

    if (form) {
        form.style.display = "none";
    }


    /*
     * Load students
     */
    getStudents();


    /*
     * Previous button
     */
    const previousButton =
        document.getElementById("previousPage");

    if (previousButton) {

        previousButton.addEventListener(
            "click",
            function () {

                if (currentPage > 1) {

                    currentPage--;

                    displayCurrentPage();

                }

            }
        );

    }


    /*
     * Next button
     */
    const nextButton =
        document.getElementById("nextPage");

    if (nextButton) {

        nextButton.addEventListener(
            "click",
            function () {

                const totalPages =
                    Math.ceil(
                        allStudents.length /
                        studentsPerPage
                    );


                if (currentPage < totalPages) {

                    currentPage++;

                    displayCurrentPage();

                }

            }
        );

    }


    /*
     * Search box - press Enter
     */
    const searchBox =
        document.getElementById("search");

    if (searchBox) {

        searchBox.addEventListener(
            "keydown",
            function (event) {

                if (event.key === "Enter") {

                    searchStudents();

                }

            }
        );

    }


    /*
     * Mobile sidebar
     */
    const menuToggle =
        document.getElementById("menuToggle");

    if (menuToggle) {

        menuToggle.addEventListener(
            "click",
            function () {

                const sidebar =
                    document.querySelector(".sidebar");

                if (sidebar) {

                    sidebar.classList.toggle("open");

                }

            }
        );

    }


    /*
     * Close mobile sidebar
     * when menu item is clicked
     */
    document
        .querySelectorAll(".menu-item")
        .forEach(item => {

            item.addEventListener(
                "click",
                function () {

                    const sidebar =
                        document.querySelector(".sidebar");

                    if (sidebar) {

                        sidebar.classList.remove("open");

                    }

                }
            );

        });

});


/* =========================================================
   GET ALL STUDENTS
   ========================================================= */

function getStudents() {

    fetch("/api/students?page=0&size=100")

        .then(response => {

            if (!response.ok) {

                throw new Error(
                    "Failed to fetch students"
                );

            }

            return response.json();

        })

        .then(data => {

            console.log(
                "Students API Response:",
                data
            );


            /*
             * Backend returns Page<Student>
             *
             * Therefore students are inside
             * data.content
             */

            if (
                data &&
                Array.isArray(data.content)
            ) {

                allStudents = data.content;

            } else {

                console.error(
                    "Unexpected API response:",
                    data
                );

                allStudents = [];

            }


            /*
             * Always start from page 1
             * after refreshing data.
             */

            currentPage = 1;


            /*
             * Display first page
             */

            displayCurrentPage();


            /*
             * Update dashboard statistics
             */

            updateDashboardCounts(allStudents);

        })

        .catch(error => {

            console.error(
                "Error loading students:",
                error
            );


            allStudents = [];


            displayCurrentPage();


            showErrorMessage(
                "Unable to load students. Please check whether the server is running."
            );

        });

}


/* =========================================================
   DISPLAY CURRENT PAGE
   ========================================================= */

function displayCurrentPage() {


    /*
     * Calculate starting index
     *
     * Page 1:
     * (1 - 1) * 10 = 0
     *
     * Page 2:
     * (2 - 1) * 10 = 10
     */

    const startIndex =
        (currentPage - 1) *
        studentsPerPage;


    /*
     * Calculate ending index
     */

    const endIndex =
        startIndex +
        studentsPerPage;


    /*
     * Get only students
     * belonging to current page
     */

    const pageStudents =
        allStudents.slice(
            startIndex,
            endIndex
        );


    /*
     * Display those students
     */

    displayStudents(
        pageStudents,
        startIndex
    );


    /*
     * Create page buttons
     */

    createPagination();


    /*
     * Update Previous / Next
     */

    updatePaginationButtons();

}


/* =========================================================
   DISPLAY STUDENTS
   ========================================================= */

function displayStudents(
    students,
    startIndex = 0
) {


    const tableBody =
        document.getElementById(
            "studentTableBody"
        );


    if (!tableBody) {

        return;

    }


    /*
     * Clear old rows
     */

    tableBody.innerHTML = "";


    /*
     * No students
     */

    if (
        !students ||
        students.length === 0
    ) {

        tableBody.innerHTML = `

            <tr>

                <td
                    colspan="6"
                    class="no-data">

                    No students found.

                </td>

            </tr>

        `;


        updateRecordInfo(
            0,
            false
        );


        return;

    }


    /*
     * Create table rows
     */

    students.forEach(
        (student, index) => {


            /*
             * IMPORTANT
             *
             * Serial number is NOT student.id.
             *
             * It is based on page position.
             *
             * Page 1:
             * 1 ... 10
             *
             * Page 2:
             * 11 ... 17
             */

            const serialNumber =
                startIndex +
                index +
                1;


            const row =
                document.createElement("tr");


            row.innerHTML = `

                <td>
                    ${serialNumber}
                </td>

                <td>
                    <strong>
                        ${escapeHtml(student.name)}
                    </strong>
                </td>

                <td>
                    ${escapeHtml(student.email)}
                </td>

                <td>

                    <span class="department-badge">

                        ${escapeHtml(
                student.department
            )}

                    </span>

                </td>

                <td>
                    ${escapeHtml(student.phone)}
                </td>

                <td>

                    <button
                        type="button"
                        class="editBtn"
                        onclick="editStudent(${student.id})">

                        ✎ Edit

                    </button>


                    <button
                        type="button"
                        class="deleteBtn"
                        onclick="deleteStudent(${student.id})">

                        🗑 Delete

                    </button>

                </td>

            `;


            tableBody.appendChild(row);

        }
    );


    /*
     * Calculate record range
     */

    const firstRecord =
        startIndex + 1;


    const lastRecord =
        startIndex +
        students.length;


    updateRecordInfoRange(
        firstRecord,
        lastRecord,
        allStudents.length
    );

}


/* =========================================================
   CREATE PAGINATION
   ========================================================= */

function createPagination() {


    const pageNumbers =
        document.getElementById(
            "pageNumbers"
        );


    if (!pageNumbers) {

        return;

    }


    pageNumbers.innerHTML = "";


    const totalPages =
        Math.ceil(
            allStudents.length /
            studentsPerPage
        );


    /*
     * If there are no students
     */

    if (totalPages === 0) {

        return;

    }


    /*
     * Create page buttons
     */

    for (
        let page = 1;
        page <= totalPages;
        page++
    ) {


        const button =
            document.createElement("button");


        button.type = "button";


        button.className =
            "pagination-button";


        button.textContent =
            page;


        /*
         * Highlight current page
         */

        if (
            page === currentPage
        ) {

            button.classList.add("active");

        }


        /*
         * Page click
         */

        button.addEventListener(
            "click",
            function () {

                currentPage = page;

                displayCurrentPage();

                /*
                 * Scroll back to student table
                 */

                const studentList =
                    document.getElementById(
                        "students"
                    );

                if (studentList) {

                    studentList.scrollIntoView({
                        behavior: "smooth",
                        block: "start"
                    });

                }

            }
        );


        pageNumbers.appendChild(
            button
        );

    }

}


/* =========================================================
   UPDATE PREVIOUS / NEXT BUTTONS
   ========================================================= */

function updatePaginationButtons() {


    const previousButton =
        document.getElementById(
            "previousPage"
        );


    const nextButton =
        document.getElementById(
            "nextPage"
        );


    const totalPages =
        Math.ceil(
            allStudents.length /
            studentsPerPage
        );


    /*
     * Previous
     */

    if (previousButton) {

        previousButton.disabled =
            currentPage <= 1;

    }


    /*
     * Next
     */

    if (nextButton) {

        nextButton.disabled =
            currentPage >= totalPages ||
            totalPages === 0;

    }

}


/* =========================================================
   UPDATE RECORD INFORMATION
   ========================================================= */

function updateRecordInfoRange(
    firstRecord,
    lastRecord,
    totalRecords
) {


    const recordInfo =
        document.getElementById(
            "recordInfo"
        );


    if (!recordInfo) {

        return;

    }


    recordInfo.textContent =
        "Showing " +
        firstRecord +
        "–" +
        lastRecord +
        " of " +
        totalRecords +
        " students";

}


/* =========================================================
   ADD / UPDATE STUDENT
   ========================================================= */

function addStudent() {


    const name =
        document
            .getElementById("name")
            .value
            .trim();


    const email =
        document
            .getElementById("email")
            .value
            .trim();


    const department =
        document
            .getElementById("department")
            .value
            .trim();


    const phone =
        document
            .getElementById("phone")
            .value
            .trim();


    /*
     * Validation
     */

    if (
        name === "" ||
        email === "" ||
        department === "" ||
        phone === ""
    ) {

        alert(
            "Please fill all student details."
        );

        return;

    }


    /*
     * Student object
     */

    const student = {

        name: name,

        email: email,

        department: department,

        phone: phone

    };


    /*
     * Decide POST or PUT
     */

    const isEditing =
        editId !== null;


    const url =
        isEditing
            ? "/api/students/" + editId
            : "/api/students";


    const method =
        isEditing
            ? "PUT"
            : "POST";


    fetch(
        url,
        {

            method: method,

            headers: {

                "Content-Type":
                    "application/json"

            },

            body:
                JSON.stringify(student)

        }
    )

        .then(response => {

            if (!response.ok) {

                throw new Error(
                    "Failed to save student"
                );

            }

            /*
             * Your POST returns JSON.
             * PUT may return JSON too.
             */

            return response.text();

        })

        .then(data => {

            console.log(
                "Save response:",
                data
            );


            if (isEditing) {

                alert(
                    "Student updated successfully!"
                );

            } else {

                alert(
                    "Student added successfully!"
                );

            }


            /*
             * Reset edit mode
             */

            editId = null;


            /*
             * Clear form
             */

            clearStudentForm();


            /*
             * Reset title
             */

            const formTitle =
                document.getElementById(
                    "formTitle"
                );

            if (formTitle) {

                formTitle.textContent =
                    "Add New Student";

            }


            /*
             * Reset button
             */

            const submitButton =
                document.getElementById(
                    "submitBtn"
                );

            if (submitButton) {

                submitButton.textContent =
                    "Add Student";

            }


            /*
             * IMPORTANT:
             *
             * Hide form after successful
             * add/update.
             */

            hideStudentForm();


            /*
             * Reload students
             */

            getStudents();

        })

        .catch(error => {

            console.error(
                "Save error:",
                error
            );


            alert(
                "Unable to save student."
            );

        });

}


/* =========================================================
   EDIT STUDENT
   ========================================================= */

function editStudent(id) {


    fetch(
        "/api/students/" + id
    )

        .then(response => {

            if (!response.ok) {

                throw new Error(
                    "Student not found"
                );

            }

            return response.json();

        })

        .then(data => {


            /*
             * Support both:
             *
             * direct Student
             *
             * or
             *
             * { data: Student }
             */

            const student =
                data.data || data;


            /*
             * Fill form
             */

            document.getElementById(
                "name"
            ).value =
                student.name || "";


            document.getElementById(
                "email"
            ).value =
                student.email || "";


            document.getElementById(
                "department"
            ).value =
                student.department || "";


            document.getElementById(
                "phone"
            ).value =
                student.phone || "";


            /*
             * Store database ID
             *
             * We still use the real ID internally
             * for UPDATE.
             */

            editId = id;


            /*
             * Change title
             */

            document.getElementById(
                "formTitle"
            ).textContent =
                "Update Student";


            /*
             * Change button
             */

            document.getElementById(
                "submitBtn"
            ).textContent =
                "Update Student";


            /*
             * Show form
             */

            showAddStudentForm();


            /*
             * Scroll to form
             */

            document.getElementById(
                "studentFormSection"
            ).scrollIntoView({
                behavior: "smooth",
                block: "start"
            });

        })

        .catch(error => {

            console.error(
                "Edit error:",
                error
            );


            alert(
                "Unable to load student details."
            );

        });

}


/* =========================================================
   DELETE STUDENT
   ========================================================= */

function deleteStudent(id) {


    const confirmed =
        confirm(
            "Are you sure you want to delete this student?"
        );


    if (!confirmed) {

        return;

    }


    fetch(
        "/api/students/" + id,
        {
            method: "DELETE"
        }
    )

        .then(response => {

            if (!response.ok) {

                throw new Error(
                    "Failed to delete student"
                );

            }

            return response.text();

        })

        .then(data => {

            console.log(
                "Delete response:",
                data
            );


            alert(
                "Student deleted successfully!"
            );


            /*
             * Reload data.
             *
             * This automatically recalculates
             * pagination and serial numbers.
             */

            getStudents();

        })

        .catch(error => {

            console.error(
                "Delete error:",
                error
            );


            alert(
                "Unable to delete student."
            );

        });

}


/* =========================================================
   SEARCH STUDENTS
   ========================================================= */

function searchStudents() {


    const searchInput =
        document.getElementById(
            "search"
        );


    if (!searchInput) {

        return;

    }


    const name =
        searchInput.value.trim();


    /*
     * Empty search
     */

    if (name === "") {

        currentPage = 1;

        displayCurrentPage();

        updateDashboardCounts(
            allStudents
        );

        return;

    }


    fetch(
        "/api/students/search?name=" +
        encodeURIComponent(name)
    )

        .then(response => {

            if (!response.ok) {

                throw new Error(
                    "Search failed"
                );

            }

            return response.json();

        })

        .then(data => {


            console.log(
                "Search response:",
                data
            );


            /*
             * Search endpoint returns List<Student>
             */

            const students =
                Array.isArray(data)
                    ? data
                    : data.content || [];


            /*
             * Temporarily use search results
             */

            allStudents =
                students;


            /*
             * Start search from page 1
             */

            currentPage = 1;


            /*
             * Display search results
             */

            displayCurrentPage();


            updateDashboardCounts(
                students
            );

        })

        .catch(error => {

            console.error(
                "Search error:",
                error
            );


            alert(
                "Unable to search students."
            );

        });

}


/* =========================================================
   CLEAR SEARCH
   ========================================================= */

function clearSearch() {


    const searchInput =
        document.getElementById(
            "search"
        );


    if (searchInput) {

        searchInput.value = "";

    }


    currentPage = 1;


    getStudents();

}


/* =========================================================
   SHOW ADD STUDENT FORM
   ========================================================= */

function showAddStudentForm() {


    const form =
        document.getElementById(
            "studentFormSection"
        );


    if (!form) {

        return;

    }


    form.style.display = "block";


    form.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });

}


/* =========================================================
   HIDE STUDENT FORM
   ========================================================= */

function hideStudentForm() {


    const form =
        document.getElementById(
            "studentFormSection"
        );


    if (!form) {

        return;

    }


    form.style.display = "none";

}


/* =========================================================
   CANCEL STUDENT FORM
   ========================================================= */

function cancelStudentForm() {


    /*
     * Reset edit mode
     */

    editId = null;


    /*
     * Clear inputs
     */

    clearStudentForm();


    /*
     * Reset title
     */

    const formTitle =
        document.getElementById(
            "formTitle"
        );


    if (formTitle) {

        formTitle.textContent =
            "Add New Student";

    }


    /*
     * Reset button
     */

    const submitButton =
        document.getElementById(
            "submitBtn"
        );


    if (submitButton) {

        submitButton.textContent =
            "Add Student";

    }


    /*
     * IMPORTANT:
     *
     * Actually hide the form.
     */

    hideStudentForm();


    /*
     * Scroll back to student list
     */

    const studentsSection =
        document.getElementById(
            "students"
        );


    if (studentsSection) {

        studentsSection.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });

    }

}


/* =========================================================
   CLEAR FORM
   ========================================================= */

function clearStudentForm() {


    const name =
        document.getElementById("name");


    const email =
        document.getElementById("email");


    const department =
        document.getElementById("department");


    const phone =
        document.getElementById("phone");


    if (name) {

        name.value = "";

    }


    if (email) {

        email.value = "";

    }


    if (department) {

        department.value = "";

    }


    if (phone) {

        phone.value = "";

    }

}


/* =========================================================
   UPDATE DASHBOARD COUNTS
   ========================================================= */

function updateDashboardCounts(
    students
) {


    const totalStudents =
        document.getElementById(
            "totalStudents"
        );


    const totalRecords =
        document.getElementById(
            "totalRecords"
        );


    const totalDepartments =
        document.getElementById(
            "totalDepartments"
        );


    const totalCourses =
        document.getElementById(
            "totalCourses"
        );


    /*
     * Total students
     */

    if (totalStudents) {

        totalStudents.textContent =
            students.length;

    }


    /*
     * Total records
     */

    if (totalRecords) {

        totalRecords.textContent =
            students.length;

    }


    /*
     * Unique departments
     */

    const departments =
        new Set();


    students.forEach(
        student => {

            if (
                student.department
            ) {

                departments.add(
                    student.department
                        .trim()
                );

            }

        }
    );


    if (totalDepartments) {

        totalDepartments.textContent =
            departments.size;

    }


    /*
     * No course field in Student entity
     */

    if (totalCourses) {

        totalCourses.textContent =
            "—";

    }

}


/* =========================================================
   ERROR MESSAGE
   ========================================================= */

function showErrorMessage(
    message
) {


    const tableBody =
        document.getElementById(
            "studentTableBody"
        );


    if (!tableBody) {

        return;

    }


    tableBody.innerHTML = `

        <tr>

            <td
                colspan="6"
                class="no-data">

                ⚠ ${escapeHtml(message)}

            </td>

        </tr>

    `;

}


/* =========================================================
   HTML SECURITY
   ========================================================= */

function escapeHtml(value) {


    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}