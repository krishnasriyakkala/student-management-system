let editId = null;
window.onload = function () {
    getStudents();
};

function getStudents() {

    fetch("/api/students?page=0&size=100")
        .then(response => response.json())
        .then(data => {

            const tableBody = document.getElementById("studentTableBody");
            tableBody.innerHTML = "";

            data.content.forEach((student, index)=> {

                let row = `
                    <tr>
                        <td>${index + 1}</td>
                        <td>${student.name}</td>
                        <td>${student.email}</td>
                        <td>${student.department}</td>
                        <td>${student.phone}</td>
                        <td>
                           <button class="editBtn" style="background-color: #28a745;" onclick="editStudent(${student.id})">Edit</button>
                        <button class="deleteBtn" style="background-color: #dc3545;" onclick="deleteStudent(${student.id})">Delete</button>
                        </td>
                    </tr>
                `;

                tableBody.innerHTML += row;
            });

        });
}
    function addStudent() {

        const student = {
            name: document.getElementById("name").value,
            email: document.getElementById("email").value,
            department: document.getElementById("department").value,
            phone: document.getElementById("phone").value
        };
        console.log(editId);
        fetch(editId ? "/api/students/" + editId : "/api/students", {
            method: editId ? "PUT" : "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(student)
        })
            .then(response => response.json())
            .then(data => {
                alert(editId ? "Student Updated Successfully!" : "Student Added Successfully!");

                editId = null;

                document.getElementById("submitBtn").innerText = "Add Student";

                document.getElementById("name").value = "";
                document.getElementById("email").value = "";
                document.getElementById("department").value = "";
                document.getElementById("phone").value = "";

                getStudents();
            })
            .catch(error => console.error(error));
    }
function editStudent(id) {
    editId = id;
    fetch("/api/students/" + id)
        .then(response => response.json())
        .then(student => {

            document.getElementById("name").value = student.name;
            document.getElementById("email").value = student.email;
            document.getElementById("department").value = student.department;
            document.getElementById("phone").value = student.phone;
            document.getElementById("submitBtn").innerText = "Update Student";

        });
}
function deleteStudent(id) {

    if (!confirm("Are you sure you want to delete this student?")) {
        return;
    }

    fetch("/api/students/" + id, {
        method: "DELETE"
    })
        .then(() => {
            alert("Student Deleted Successfully!");
            getStudents();
        })
        .catch(error => console.error(error));

}
function searchStudents() {

    const name = document.getElementById("search").value.trim();

    if (name === "") {
        getStudents();
        return;
    }

    fetch("/api/students/search?name=" + encodeURIComponent(name))
        .then(response => response.json())
        .then(data => {
            console.log("Data:", data);
            console.log("Length:", data.length);

            const tableBody = document.getElementById("studentTableBody");
            tableBody.innerHTML = "";

            data.forEach((student, index) => {
                console.log(student);
                let row = `
                <tr>
                    <td>${index + 1}</td>
                    <td>${student.name}</td>
                    <td>${student.email}</td>
                    <td>${student.department}</td>
                    <td>${student.phone}</td>
                    <td>
                        <button class="editBtn" style="background-color: #28a745;" onclick="editStudent(${student.id})">Edit</button>
                        <button class="deleteBtn" style="background-color: #dc3545;" onclick="deleteStudent(${student.id})">Delete</button>
                    </td>
                </tr>
                `;

                tableBody.innerHTML += row;
            });

        });
}