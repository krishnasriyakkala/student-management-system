package com.rck.studentmanagementsystem;

import com.rck.studentmanagementsystem.entity.Student;
import com.rck.studentmanagementsystem.repository.StudentRepository;
import com.rck.studentmanagementsystem.service.StudentService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

public class StudentServiceTest {

    @Mock
    private StudentRepository studentRepository;

    @InjectMocks
    private StudentService studentService;

    public StudentServiceTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveStudent() {
        Student student = new Student();

        student.setName("Charan");
        student.setEmail("charan@gmail.com");
        student.setDepartment("CSE");
        student.setPhone("9876543210");
        when(studentRepository.save(student)).thenReturn(student);
        Student savedStudent = studentService.saveStudent(student);
        assertEquals("Charan", savedStudent.getName());
        verify(studentRepository).save(student);
    }
    @Test
    void testGetStudentById() {

        Long id = 1L;

        Student student = new Student();

        student.setId(id);
        student.setName("Charan");
        student.setEmail("charan@gmail.com");
        student.setDepartment("CSE");
        student.setPhone("9876543210");
        when(studentRepository.findById(id))
                .thenReturn(java.util.Optional.of(student));
        Student foundStudent = studentService.getStudentById(id);
        assertEquals("Charan", foundStudent.getName());
    }
    @Test
    void testDeleteStudent() {

        Long id = 1L;

        studentService.deleteStudent(id);

        verify(studentRepository).deleteById(id);
    }
    @Test
    void testGetStudentCount() {

        when(studentRepository.count()).thenReturn(5L);

        long count = studentService.getStudentCount();

        assertEquals(5L, count);

        verify(studentRepository).count();
    }
}